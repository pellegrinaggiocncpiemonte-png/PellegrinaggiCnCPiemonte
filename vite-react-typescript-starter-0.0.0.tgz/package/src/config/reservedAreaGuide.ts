export type ReservedAreaGuideItem = {
  id: string;
  title: string;
  icon: string;
  description: string;
  bullets?: string[];
  note?: string;
};

export const RESERVED_AREA_GUIDE_TITLE = 'Come registrarsi all\'app';
export const RESERVED_AREA_GUIDE_SUBTITLE =
  'Segui queste indicazioni per scegliere il profilo corretto durante la registrazione all\'area riservata.';

export const RESERVED_AREA_GUIDE_ITEMS: ReservedAreaGuideItem[] = [
  {
    id: 'partecipante',
    title: 'Partecipante',
    icon: '🏃',
    description:
      'È il profilo principale per chi vive il pellegrinaggio e deve essere scelto da:',
    bullets: [
      'Giovani minori e maggiorenni.',
      'Accompagnatori e catechisti che partecipano attivamente al cammino.',
      'Responsabili di comunità in cammino con i ragazzi.',
      'Genitori che partecipano fisicamente all’evento.',
    ],
  },
  {
    id: 'responsabile',
    title: 'Responsabile',
    icon: '🛡️',
    description:
      'Profilo dedicato a chi ha il compito di coordinare e gestire il gruppo di giovani a lui associati.',
  },
  {
    id: 'collaboratore',
    title: 'Collaboratore',
    icon: '🤝',
    description:
      'Profilo specifico per catechisti e accompagnatori che supportano la gestione organizzativa.',
  },
  {
    id: 'genitore-codice',
    title: 'Genitore (con codice)',
    icon: '👨‍👩‍👧',
    description:
      'Da scegliere se tuo figlio si è iscritto autonomamente come Partecipante.',
    note:
      'Se tuo figlio è minore, dovrà inviarti un codice di verifica via email dalla sua sezione “Profilo” per permetterti di registrarti.',
  },
  {
    id: 'genitore-figli',
    title: 'Genitore + Figli (senza email)',
    icon: '👥',
    description:
      'Da scegliere se devi gestire figli che non hanno un indirizzo email personale.',
    note:
      'Utilizzerai la tua email per registrarli e potrai creare i profili figli. Per gestirli dovrai impersonare ogni singolo figlio dal tuo pannello, così da completare le loro iscrizioni.',
  },
];
